
const Cart = require('../models/cart.model');
const Product = require('../models/product.model');
const { ApiError, asyncHandler } = require('../utils/api-error');

/**
 * @desc    Get user cart
 * @route   GET /api/cart
 * @access  Private
 */
const getCart = asyncHandler(async (req, res) => {
  let cart = await Cart.findOne({ userId: req.user._id });
  
  if (!cart) {
    cart = await Cart.create({
      userId: req.user._id,
      items: [],
      totalItems: 0,
      totalPrice: 0
    });
  }
  
  res.status(200).json({
    success: true,
    data: cart
  });
});

/**
 * @desc    Add item to cart
 * @route   POST /api/cart/items
 * @access  Private
 */
const addToCart = asyncHandler(async (req, res) => {
  const { productId, quantity = 1 } = req.body;
  
  // Validate product exists
  const product = await Product.findById(productId);
  
  if (!product) {
    throw new ApiError('Product not found', 404);
  }
  
  if (!product.isActive) {
    throw new ApiError('Product is not available', 400);
  }
  
  if (product.stock < quantity) {
    throw new ApiError('Not enough stock available', 400);
  }
  
  // Find user's cart or create one
  let cart = await Cart.findOne({ userId: req.user._id });
  
  if (!cart) {
    cart = await Cart.create({
      userId: req.user._id,
      items: [],
      totalItems: 0,
      totalPrice: 0
    });
  }
  
  // Check if product already exists in cart
  const itemIndex = cart.items.findIndex(item => 
    item.productId.toString() === productId
  );
  
  if (itemIndex > -1) {
    // Product exists in cart, update quantity
    cart.items[itemIndex].quantity += quantity;
  } else {
    // Product not in cart, add new item
    const primaryImage = product.images.find(img => img.isPrimary) || product.images[0];
    
    cart.items.push({
      productId,
      quantity,
      price: product.price,
      title: product.title,
      image: primaryImage ? primaryImage.url : ''
    });
  }
  
  // Save updated cart
  await cart.save();
  
  res.status(200).json({
    success: true,
    data: cart
  });
});

/**
 * @desc    Update cart item quantity
 * @route   PUT /api/cart/items/:productId
 * @access  Private
 */
const updateCartItem = asyncHandler(async (req, res) => {
  const { quantity } = req.body;
  const { productId } = req.params;
  
  if (!quantity || quantity < 1) {
    throw new ApiError('Quantity must be at least 1', 400);
  }
  
  // Validate product exists and has enough stock
  const product = await Product.findById(productId);
  
  if (!product) {
    throw new ApiError('Product not found', 404);
  }
  
  if (product.stock < quantity) {
    throw new ApiError('Not enough stock available', 400);
  }
  
  // Find user's cart
  const cart = await Cart.findOne({ userId: req.user._id });
  
  if (!cart) {
    throw new ApiError('Cart not found', 404);
  }
  
  // Find item in cart
  const itemIndex = cart.items.findIndex(item => 
    item.productId.toString() === productId
  );
  
  if (itemIndex === -1) {
    throw new ApiError('Item not found in cart', 404);
  }
  
  // Update item quantity
  cart.items[itemIndex].quantity = quantity;
  
  // Save updated cart
  await cart.save();
  
  res.status(200).json({
    success: true,
    data: cart
  });
});

/**
 * @desc    Remove item from cart
 * @route   DELETE /api/cart/items/:productId
 * @access  Private
 */
const removeCartItem = asyncHandler(async (req, res) => {
  const { productId } = req.params;
  
  // Find user's cart
  const cart = await Cart.findOne({ userId: req.user._id });
  
  if (!cart) {
    throw new ApiError('Cart not found', 404);
  }
  
  // Find item index
  const itemIndex = cart.items.findIndex(item => 
    item.productId.toString() === productId
  );
  
  if (itemIndex === -1) {
    throw new ApiError('Item not found in cart', 404);
  }
  
  // Remove item from cart
  cart.items.splice(itemIndex, 1);
  
  // Save updated cart
  await cart.save();
  
  res.status(200).json({
    success: true,
    data: cart
  });
});

/**
 * @desc    Clear cart
 * @route   DELETE /api/cart
 * @access  Private
 */
const clearCart = asyncHandler(async (req, res) => {
  // Find user's cart
  const cart = await Cart.findOne({ userId: req.user._id });
  
  if (!cart) {
    throw new ApiError('Cart not found', 404);
  }
  
  // Clear items
  cart.items = [];
  
  // Save updated cart
  await cart.save();
  
  res.status(200).json({
    success: true,
    message: 'Cart cleared successfully',
    data: cart
  });
});

module.exports = {
  getCart,
  addToCart,
  updateCartItem,
  removeCartItem,
  clearCart
};
