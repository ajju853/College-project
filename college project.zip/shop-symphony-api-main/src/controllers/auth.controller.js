
const jwt = require('jsonwebtoken');
const User = require('../models/user.model');
const { ApiError, asyncHandler } = require('../utils/api-error');

/**
 * Generate JWT token for user authentication
 */
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '30d'
  });
};

/**
 * @desc    Register a new user
 * @route   POST /api/auth/register
 * @access  Public
 */
const register = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;
  
  // Check if user already exists
  const userExists = await User.findOne({ email });
  
  if (userExists) {
    throw new ApiError('User already exists', 400);
  }
  
  // Create new user
  const user = await User.create({
    name,
    email,
    password
  });
  
  // Generate token
  const token = generateToken(user._id);
  
  res.status(201).json({
    success: true,
    data: {
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      token
    }
  });
});

/**
 * @desc    Login user
 * @route   POST /api/auth/login
 * @access  Public
 */
const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  
  // Check if email and password are provided
  if (!email || !password) {
    throw new ApiError('Please provide email and password', 400);
  }
  
  // Find user by email
  const user = await User.findOne({ email });
  
  // Check if user exists and password is correct
  if (!user || !(await user.comparePassword(password))) {
    throw new ApiError('Invalid credentials', 401);
  }
  
  // Check if user is active
  if (!user.isActive) {
    throw new ApiError('Your account has been deactivated', 403);
  }
  
  // Generate token
  const token = generateToken(user._id);
  
  res.status(200).json({
    success: true,
    data: {
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      token
    }
  });
});

/**
 * @desc    Get currently logged in user
 * @route   GET /api/auth/me
 * @access  Private
 */
const getMe = asyncHandler(async (req, res) => {
  // User already attached to request from auth middleware
  res.status(200).json({
    success: true,
    data: req.user
  });
});

module.exports = {
  register,
  login,
  getMe
};
