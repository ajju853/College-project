
const Order = require('../models/order.model');
const Product = require('../models/product.model');
const User = require('../models/user.model');
const { ApiError, asyncHandler } = require('../utils/api-error');

/**
 * @desc    Get dashboard stats
 * @route   GET /api/admin/dashboard
 * @access  Private/Admin
 */
const getDashboardStats = asyncHandler(async (req, res) => {
  // Get total revenue
  const orders = await Order.find({ paymentStatus: 'completed' });
  const totalRevenue = orders.reduce((sum, order) => sum + order.totalAmount, 0);
  
  // Get counts
  const totalUsers = await User.countDocuments();
  const totalProducts = await Product.countDocuments();
  const totalOrders = await Order.countDocuments();
  const pendingOrders = await Order.countDocuments({ status: 'pending' });
  
  // Get low stock products
  const lowStockThreshold = 5;
  const lowStockProducts = await Product.find({ stock: { $lt: lowStockThreshold } })
    .select('title stock')
    .limit(10);
  
  // Get recent orders
  const recentOrders = await Order.find()
    .sort({ createdAt: -1 })
    .limit(5);
  
  res.status(200).json({
    success: true,
    data: {
      stats: {
        totalRevenue,
        totalUsers,
        totalProducts,
        totalOrders,
        pendingOrders
      },
      lowStockProducts,
      recentOrders
    }
  });
});

/**
 * @desc    Get sales report by time period
 * @route   GET /api/admin/reports/sales
 * @access  Private/Admin
 */
const getSalesReport = asyncHandler(async (req, res) => {
  const { period, startDate, endDate } = req.query;
  
  let dateQuery = {};
  let groupFormat;
  
  // Set query based on period
  if (startDate && endDate) {
    dateQuery = {
      createdAt: {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      }
    };
  }
  
  // Set group format based on period
  switch (period) {
    case 'daily':
      groupFormat = { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } };
      break;
    case 'weekly':
      groupFormat = { 
        $dateToString: { 
          format: '%G-W%V', 
          date: '$createdAt' 
        } 
      };
      break;
    case 'monthly':
      groupFormat = { $dateToString: { format: '%Y-%m', date: '$createdAt' } };
      break;
    default:
      groupFormat = { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } };
  }
  
  // Execute aggregation
  const salesReport = await Order.aggregate([
    { 
      $match: { 
        ...dateQuery,
        paymentStatus: 'completed' 
      } 
    },
    {
      $group: {
        _id: groupFormat,
        totalSales: { $sum: '$totalAmount' },
        orderCount: { $sum: 1 }
      }
    },
    { $sort: { _id: 1 } }
  ]);
  
  res.status(200).json({
    success: true,
    data: salesReport
  });
});

/**
 * @desc    Get product performance report
 * @route   GET /api/admin/reports/products
 * @access  Private/Admin
 */
const getProductReport = asyncHandler(async (req, res) => {
  const { period, limit = 10 } = req.query;
  
  let dateQuery = {};
  
  // Set query based on period
  if (period) {
    const now = new Date();
    let startDate;
    
    switch (period) {
      case 'week':
        startDate = new Date(now.setDate(now.getDate() - 7));
        break;
      case 'month':
        startDate = new Date(now.setMonth(now.getMonth() - 1));
        break;
      case 'year':
        startDate = new Date(now.setFullYear(now.getFullYear() - 1));
        break;
      default:
        startDate = new Date(0); // All time
    }
    
    dateQuery = { createdAt: { $gte: startDate } };
  }
  
  // Execute aggregation
  const productReport = await Order.aggregate([
    { 
      $match: { 
        ...dateQuery,
        paymentStatus: 'completed' 
      } 
    },
    { $unwind: '$items' },
    {
      $group: {
        _id: '$items.productId',
        totalSold: { $sum: '$items.quantity' },
        totalRevenue: { $sum: { $multiply: ['$items.price', '$items.quantity'] } },
        productTitle: { $first: '$items.title' }
      }
    },
    { $sort: { totalRevenue: -1 } },
    { $limit: parseInt(limit, 10) }
  ]);
  
  res.status(200).json({
    success: true,
    data: productReport
  });
});

/**
 * @desc    Get customer report
 * @route   GET /api/admin/reports/customers
 * @access  Private/Admin
 */
const getCustomerReport = asyncHandler(async (req, res) => {
  const { limit = 10 } = req.query;
  
  // Execute aggregation
  const customerReport = await Order.aggregate([
    { $match: { paymentStatus: 'completed' } },
    {
      $group: {
        _id: '$userId',
        orderCount: { $sum: 1 },
        totalSpent: { $sum: '$totalAmount' },
        lastOrder: { $max: '$createdAt' }
      }
    },
    {
      $lookup: {
        from: 'users',
        localField: '_id',
        foreignField: '_id',
        as: 'userInfo'
      }
    },
    { $unwind: '$userInfo' },
    {
      $project: {
        _id: 1,
        name: '$userInfo.name',
        email: '$userInfo.email',
        orderCount: 1,
        totalSpent: 1,
        lastOrder: 1
      }
    },
    { $sort: { totalSpent: -1 } },
    { $limit: parseInt(limit, 10) }
  ]);
  
  res.status(200).json({
    success: true,
    data: customerReport
  });
});

module.exports = {
  getDashboardStats,
  getSalesReport,
  getProductReport,
  getCustomerReport
};
