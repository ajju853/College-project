
const Product = require('../models/product.model');
const { ApiError, asyncHandler } = require('../utils/api-error');

/**
 * @desc    Get all products with filtering, sorting and pagination
 * @route   GET /api/products
 * @access  Public
 */
const getProducts = asyncHandler(async (req, res) => {
  // Build query
  let query = {};
  
  // Filtering
  if (req.query.category) {
    query.category = req.query.category;
  }
  
  if (req.query.minPrice || req.query.maxPrice) {
    query.price = {};
    if (req.query.minPrice) query.price.$gte = Number(req.query.minPrice);
    if (req.query.maxPrice) query.price.$lte = Number(req.query.maxPrice);
  }
  
  if (req.query.featured) {
    query.featured = req.query.featured === 'true';
  }
  
  // Search
  if (req.query.search) {
    query.$text = { $search: req.query.search };
  }
  
  // Only show active products unless specifically requested by admin
  if (!req.query.showAll || req.user?.role !== 'admin') {
    query.isActive = true;
  }
  
  // Pagination
  const page = parseInt(req.query.page, 10) || 1;
  const limit = parseInt(req.query.limit, 10) || 10;
  const skip = (page - 1) * limit;
  
  // Sorting
  let sort = {};
  if (req.query.sort) {
    const sortFields = req.query.sort.split(',');
    sortFields.forEach(field => {
      if (field.startsWith('-')) {
        sort[field.substring(1)] = -1;
      } else {
        sort[field] = 1;
      }
    });
  } else {
    sort = { createdAt: -1 }; // Default sort by newest
  }
  
  // Execute query
  const products = await Product.find(query)
    .sort(sort)
    .skip(skip)
    .limit(limit);
  
  // Get total count
  const total = await Product.countDocuments(query);
  
  res.status(200).json({
    success: true,
    count: products.length,
    pagination: {
      total,
      page,
      pages: Math.ceil(total / limit)
    },
    data: products
  });
});

/**
 * @desc    Get single product by ID
 * @route   GET /api/products/:id
 * @access  Public
 */
const getProductById = asyncHandler(async (req, res) => {
  const product = await Product.findById(req.params.id);
  
  if (!product) {
    throw new ApiError('Product not found', 404);
  }
  
  // Only show active products unless admin
  if (!product.isActive && (!req.user || req.user.role !== 'admin')) {
    throw new ApiError('Product not found', 404);
  }
  
  res.status(200).json({
    success: true,
    data: product
  });
});

/**
 * @desc    Create a product
 * @route   POST /api/products
 * @access  Private/Admin
 */
const createProduct = asyncHandler(async (req, res) => {
  const product = await Product.create(req.body);
  
  res.status(201).json({
    success: true,
    data: product
  });
});

/**
 * @desc    Update a product
 * @route   PUT /api/products/:id
 * @access  Private/Admin
 */
const updateProduct = asyncHandler(async (req, res) => {
  let product = await Product.findById(req.params.id);
  
  if (!product) {
    throw new ApiError('Product not found', 404);
  }
  
  product = await Product.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });
  
  res.status(200).json({
    success: true,
    data: product
  });
});

/**
 * @desc    Delete a product
 * @route   DELETE /api/products/:id
 * @access  Private/Admin
 */
const deleteProduct = asyncHandler(async (req, res) => {
  const product = await Product.findById(req.params.id);
  
  if (!product) {
    throw new ApiError('Product not found', 404);
  }
  
  await product.deleteOne();
  
  res.status(200).json({
    success: true,
    message: 'Product deleted successfully'
  });
});

/**
 * @desc    Add product rating
 * @route   POST /api/products/:id/ratings
 * @access  Private
 */
const addProductRating = asyncHandler(async (req, res) => {
  const { rating, review } = req.body;
  const userId = req.user._id;
  
  if (!rating || rating < 1 || rating > 5) {
    throw new ApiError('Rating must be between 1 and 5', 400);
  }
  
  const product = await Product.findById(req.params.id);
  
  if (!product) {
    throw new ApiError('Product not found', 404);
  }
  
  // Check if user already rated this product
  const alreadyRated = product.ratings.find(
    (r) => r.userId.toString() === userId.toString()
  );
  
  if (alreadyRated) {
    // Update existing rating
    product.ratings.forEach((r) => {
      if (r.userId.toString() === userId.toString()) {
        r.rating = rating;
        r.review = review || r.review;
      }
    });
  } else {
    // Add new rating
    product.ratings.push({
      userId,
      rating,
      review
    });
  }
  
  // Save product with updated ratings
  await product.save();
  
  res.status(200).json({
    success: true,
    data: product
  });
});

module.exports = {
  getProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
  addProductRating
};
