
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const Order = require('../models/order.model');
const { ApiError, asyncHandler } = require('../utils/api-error');

/**
 * @desc    Create Stripe payment intent
 * @route   POST /api/payments/stripe/create-payment-intent
 * @access  Private
 */
const createStripePaymentIntent = asyncHandler(async (req, res) => {
  const { orderId } = req.body;
  
  // Validate order
  const order = await Order.findById(orderId);
  
  if (!order) {
    throw new ApiError('Order not found', 404);
  }
  
  if (order.userId.toString() !== req.user._id.toString()) {
    throw new ApiError('Not authorized to pay for this order', 403);
  }
  
  if (order.paymentStatus !== 'pending') {
    throw new ApiError('This order has already been paid', 400);
  }
  
  // Create payment intent
  const paymentIntent = await stripe.paymentIntents.create({
    amount: Math.round(order.totalAmount * 100), // convert to cents
    currency: 'usd',
    metadata: {
      orderId: order._id.toString(),
      userId: req.user._id.toString()
    }
  });
  
  res.status(200).json({
    success: true,
    clientSecret: paymentIntent.client_secret
  });
});

/**
 * @desc    Process Stripe payment webhook
 * @route   POST /api/payments/stripe/webhook
 * @access  Public
 */
const stripeWebhook = asyncHandler(async (req, res) => {
  const signature = req.headers['stripe-signature'];
  
  let event;
  
  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error(`Webhook signature verification failed: ${err.message}`);
    throw new ApiError('Webhook signature verification failed', 400);
  }
  
  // Handle the event
  if (event.type === 'payment_intent.succeeded') {
    const paymentIntent = event.data.object;
    await handleSuccessfulPayment(paymentIntent);
  }
  
  res.status(200).json({ received: true });
});

/**
 * Handle successful payment
 */
const handleSuccessfulPayment = async (paymentIntent) => {
  const { orderId } = paymentIntent.metadata;
  
  // Update order payment status
  const order = await Order.findById(orderId);
  
  if (!order) {
    console.error(`Order not found: ${orderId}`);
    return;
  }
  
  order.paymentStatus = 'completed';
  order.paymentDetails = {
    transactionId: paymentIntent.id,
    paymentMethod: 'stripe',
    paymentDate: new Date(),
    receiptUrl: paymentIntent.charges.data[0]?.receipt_url
  };
  
  await order.save();
};

/**
 * @desc    Process PayPal payment webhook
 * @route   POST /api/payments/paypal/webhook
 * @access  Public
 */
const paypalWebhook = asyncHandler(async (req, res) => {
  // Implementation would depend on PayPal SDK, but follows similar pattern
  // to the Stripe webhook above
  
  res.status(200).json({ received: true });
});

/**
 * @desc    Get payment status for order
 * @route   GET /api/payments/status/:orderId
 * @access  Private
 */
const getPaymentStatus = asyncHandler(async (req, res) => {
  const { orderId } = req.params;
  
  const order = await Order.findById(orderId);
  
  if (!order) {
    throw new ApiError('Order not found', 404);
  }
  
  if (order.userId.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
    throw new ApiError('Not authorized to view this payment', 403);
  }
  
  res.status(200).json({
    success: true,
    data: {
      orderId: order._id,
      paymentStatus: order.paymentStatus,
      paymentDetails: order.paymentDetails
    }
  });
});

module.exports = {
  createStripePaymentIntent,
  stripeWebhook,
  paypalWebhook,
  getPaymentStatus
};
