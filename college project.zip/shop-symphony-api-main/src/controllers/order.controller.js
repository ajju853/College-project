
const Order = require('../models/order.model');
const Cart = require('../models/cart.model');
const Product = require('../models/product.model');
const { ApiError, asyncHandler } = require('../utils/api-error');

/**
 * @desc    Create new order
 * @route   POST /api/orders
 * @access  Private
 */
const createOrder = asyncHandler(async (req, res) => {
  const { 
    shippingAddress, 
    paymentMethod,
    shippingMethod,
    notes 
  } = req.body;
  
  // Find user's cart
  const cart = await Cart.findOne({ userId: req.user._id });
  
  if (!cart || cart.items.length === 0) {
    throw new ApiError('Cart is empty', 400);
  }
  
  // Validate items stock
  for (const item of cart.items) {
    const product = await Product.findById(item.productId);
    
    if (!product) {
      throw new ApiError(`Product ${item.title} no longer exists`, 400);
    }
    
    if (!product.isActive) {
      throw new ApiError(`Product ${item.title} is no longer available`, 400);
    }
    
    if (product.stock < item.quantity) {
      throw new ApiError(`Not enough ${item.title} in stock. Available: ${product.stock}`, 400);
    }
  }
  
  // Create order
  const order = await Order.create({
    userId: req.user._id,
    items: cart.items,
    totalAmount: cart.totalPrice,
    shippingAddress,
    paymentMethod,
    shippingMethod,
    notes
  });
  
  // Update product stock
  for (const item of cart.items) {
    await Product.findByIdAndUpdate(item.productId, {
      $inc: { stock: -item.quantity }
    });
  }
  
  // Clear cart
  cart.items = [];
  await cart.save();
  
  res.status(201).json({
    success: true,
    data: order
  });
});

/**
 * @desc    Get user orders
 * @route   GET /api/orders
 * @access  Private
 */
const getUserOrders = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page, 10) || 1;
  const limit = parseInt(req.query.limit, 10) || 10;
  const skip = (page - 1) * limit;
  
  const orders = await Order.find({ userId: req.user._id })
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit);
  
  const total = await Order.countDocuments({ userId: req.user._id });
  
  res.status(200).json({
    success: true,
    count: orders.length,
    pagination: {
      total,
      page,
      pages: Math.ceil(total / limit)
    },
    data: orders
  });
});

/**
 * @desc    Get order by ID
 * @route   GET /api/orders/:id
 * @access  Private
 */
const getOrderById = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id);
  
  if (!order) {
    throw new ApiError('Order not found', 404);
  }
  
  // Check if order belongs to user or user is admin
  if (order.userId.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
    throw new ApiError('Not authorized to access this order', 403);
  }
  
  res.status(200).json({
    success: true,
    data: order
  });
});

/**
 * @desc    Update order status (admin only)
 * @route   PUT /api/orders/:id
 * @access  Private/Admin
 */
const updateOrderStatus = asyncHandler(async (req, res) => {
  const { status, trackingNumber, estimatedDelivery } = req.body;
  
  const order = await Order.findById(req.params.id);
  
  if (!order) {
    throw new ApiError('Order not found', 404);
  }
  
  // Update fields
  if (status) order.status = status;
  if (trackingNumber) order.trackingNumber = trackingNumber;
  if (estimatedDelivery) order.estimatedDelivery = estimatedDelivery;
  
  // Save order
  await order.save();
  
  res.status(200).json({
    success: true,
    data: order
  });
});

/**
 * @desc    Cancel order
 * @route   PUT /api/orders/:id/cancel
 * @access  Private
 */
const cancelOrder = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id);
  
  if (!order) {
    throw new ApiError('Order not found', 404);
  }
  
  // Check if order belongs to user or user is admin
  if (order.userId.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
    throw new ApiError('Not authorized to cancel this order', 403);
  }
  
  // Check if order can be cancelled
  if (order.status !== 'pending' && order.status !== 'processing') {
    throw new ApiError('Order cannot be cancelled at this stage', 400);
  }
  
  // Update status to cancelled
  order.status = 'cancelled';
  
  // Restore product stock
  for (const item of order.items) {
    await Product.findByIdAndUpdate(item.productId, {
      $inc: { stock: item.quantity }
    });
  }
  
  // Save order
  await order.save();
  
  res.status(200).json({
    success: true,
    data: order
  });
});

/**
 * @desc    Get all orders (admin only)
 * @route   GET /api/admin/orders
 * @access  Private/Admin
 */
const getAllOrders = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page, 10) || 1;
  const limit = parseInt(req.query.limit, 10) || 10;
  const skip = (page - 1) * limit;
  
  // Filter
  let query = {};
  if (req.query.status) {
    query.status = req.query.status;
  }
  
  if (req.query.userId) {
    query.userId = req.query.userId;
  }
  
  // Date range
  if (req.query.startDate || req.query.endDate) {
    query.createdAt = {};
    if (req.query.startDate) {
      query.createdAt.$gte = new Date(req.query.startDate);
    }
    if (req.query.endDate) {
      query.createdAt.$lte = new Date(req.query.endDate);
    }
  }
  
  const orders = await Order.find(query)
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit);
  
  const total = await Order.countDocuments(query);
  
  res.status(200).json({
    success: true,
    count: orders.length,
    pagination: {
      total,
      page,
      pages: Math.ceil(total / limit)
    },
    data: orders
  });
});

module.exports = {
  createOrder,
  getUserOrders,
  getOrderById,
  updateOrderStatus,
  cancelOrder,
  getAllOrders
};
