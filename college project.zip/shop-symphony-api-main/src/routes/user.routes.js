
const express = require('express');
const router = express.Router();
const { 
  getAllUsers,
  getUserById,
  updateProfile,
  updateUser,
  deleteUser
} = require('../controllers/user.controller');
const { 
  authenticate, 
  authorizeAdmin 
} = require('../middleware/auth.middleware');

// User routes
router.route('/profile')
  .put(authenticate, updateProfile);

// Admin routes
router.route('/')
  .get(authenticate, authorizeAdmin, getAllUsers);

router.route('/:id')
  .get(authenticate, authorizeAdmin, getUserById)
  .put(authenticate, authorizeAdmin, updateUser)
  .delete(authenticate, authorizeAdmin, deleteUser);

module.exports = router;
