
const express = require('express');
const router = express.Router();
const { 
  getDashboardStats,
  getSalesReport,
  getProductReport,
  getCustomerReport
} = require('../controllers/admin.controller');
const { getAllOrders } = require('../controllers/order.controller');
const { 
  authenticate, 
  authorizeAdmin 
} = require('../middleware/auth.middleware');

// All admin routes are protected and require admin role
router.use(authenticate, authorizeAdmin);

router.get('/dashboard', getDashboardStats);
router.get('/orders', getAllOrders);
router.get('/reports/sales', getSalesReport);
router.get('/reports/products', getProductReport);
router.get('/reports/customers', getCustomerReport);

module.exports = router;
