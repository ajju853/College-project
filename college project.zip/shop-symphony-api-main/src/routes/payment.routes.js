
const express = require('express');
const router = express.Router();
const { 
  createStripePaymentIntent,
  stripeWebhook,
  paypalWebhook,
  getPaymentStatus
} = require('../controllers/payment.controller');
const { authenticate } = require('../middleware/auth.middleware');

// Webhook routes (public)
router.post('/stripe/webhook', express.raw({ type: 'application/json' }), stripeWebhook);
router.post('/paypal/webhook', paypalWebhook);

// Protected routes
router.use(authenticate);

router.post('/stripe/create-payment-intent', createStripePaymentIntent);
router.get('/status/:orderId', getPaymentStatus);

module.exports = router;
