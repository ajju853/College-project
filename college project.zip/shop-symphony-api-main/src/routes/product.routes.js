
const express = require('express');
const router = express.Router();
const { 
  getProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
  addProductRating
} = require('../controllers/product.controller');
const { 
  authenticate, 
  authorizeAdmin 
} = require('../middleware/auth.middleware');

// Public routes
router.route('/')
  .get(getProducts);

router.route('/:id')
  .get(getProductById);

// Protected routes
router.route('/:id/ratings')
  .post(authenticate, addProductRating);

// Admin routes
router.route('/')
  .post(authenticate, authorizeAdmin, createProduct);

router.route('/:id')
  .put(authenticate, authorizeAdmin, updateProduct)
  .delete(authenticate, authorizeAdmin, deleteProduct);

module.exports = router;
