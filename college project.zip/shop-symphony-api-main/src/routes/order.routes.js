
const express = require('express');
const router = express.Router();
const { 
  createOrder,
  getUserOrders,
  getOrderById,
  updateOrderStatus,
  cancelOrder,
  getAllOrders
} = require('../controllers/order.controller');
const { 
  authenticate, 
  authorizeAdmin 
} = require('../middleware/auth.middleware');

// All order routes are protected
router.use(authenticate);

// User routes
router.route('/')
  .post(createOrder)
  .get(getUserOrders);

router.route('/:id')
  .get(getOrderById);

router.route('/:id/cancel')
  .put(cancelOrder);

// Admin routes
router.route('/:id')
  .put(authorizeAdmin, updateOrderStatus);

module.exports = router;
