
const express = require('express');
const router = express.Router();
const { 
  getCart,
  addToCart,
  updateCartItem,
  removeCartItem,
  clearCart
} = require('../controllers/cart.controller');
const { authenticate } = require('../middleware/auth.middleware');

// All cart routes are protected
router.use(authenticate);

router.route('/')
  .get(getCart)
  .delete(clearCart);

router.route('/items')
  .post(addToCart);

router.route('/items/:productId')
  .put(updateCartItem)
  .delete(removeCartItem);

module.exports = router;
