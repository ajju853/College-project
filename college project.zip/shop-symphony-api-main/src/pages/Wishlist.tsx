
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { ShoppingCart, Search, Heart, User, Trash2 } from "lucide-react";

const Wishlist = () => {
  // Mock wishlist data
  const [wishlistItems, setWishlistItems] = useState([
    {
      id: 1,
      name: "Premium Wireless Headphones",
      price: 129.99,
      image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&auto=format&fit=crop&q=80",
      description: "High-quality wireless headphones with noise cancellation and 30-hour battery life."
    },
    {
      id: 3,
      name: "Ultra HD 4K Smart TV",
      price: 649.99,
      image: "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=500&auto=format&fit=crop&q=80",
      description: "Immersive viewing experience with stunning 4K resolution and smart features."
    },
    {
      id: 5,
      name: "Ergonomic Office Chair",
      price: 199.99,
      image: "https://images.unsplash.com/photo-1580480055273-228ff5388ef8?w=500&auto=format&fit=crop&q=80",
      description: "Work comfortably with this ergonomic design and adjustable features."
    }
  ]);

  // Handler for removing item from wishlist
  const removeItem = (id) => {
    setWishlistItems(wishlistItems.filter(item => item.id !== id));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-gray-800">ShopSymphony</h1>
            </div>
            
            <div className="hidden md:flex items-center space-x-6">
              <Link to="/" className="text-gray-700 hover:text-gray-900 font-medium">Home</Link>
              <Link to="/products" className="text-gray-700 hover:text-gray-900 font-medium">Products</Link>
              <Link to="/categories" className="text-gray-700 hover:text-gray-900 font-medium">Categories</Link>
              <Link to="/deals" className="text-gray-700 hover:text-gray-900 font-medium">Deals</Link>
            </div>
            
            <div className="flex items-center space-x-4">
              <button className="text-gray-700 hover:text-gray-900">
                <Search size={20} />
              </button>
              <Link to="/profile" className="text-gray-700 hover:text-gray-900">
                <User size={20} />
              </Link>
              <Link to="/wishlist" className="text-blue-600">
                <Heart size={20} />
              </Link>
              <Link to="/cart" className="text-gray-700 hover:text-gray-900 relative">
                <ShoppingCart size={20} />
                <span className="absolute -top-2 -right-2 bg-blue-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  0
                </span>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Wishlist Section */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold mb-8">Your Wishlist</h1>
          
          {wishlistItems.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {wishlistItems.map((item) => (
                <Card key={item.id} className="h-full">
                  <CardContent className="p-0">
                    <div className="h-60 overflow-hidden">
                      <img 
                        src={item.image} 
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="p-6">
                      <h3 className="text-xl font-semibold mb-2">{item.name}</h3>
                      <p className="text-gray-600 mb-4">{item.description}</p>
                      <div className="flex justify-between items-center">
                        <span className="text-xl font-bold">${item.price.toFixed(2)}</span>
                        <div className="flex space-x-2">
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="text-red-500 border-red-500 hover:bg-red-50"
                            onClick={() => removeItem(item.id)}
                          >
                            <Trash2 size={16} className="mr-1" /> Remove
                          </Button>
                          <Button size="sm">
                            <ShoppingCart size={16} className="mr-1" /> Add to Cart
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="text-center p-8">
              <CardContent className="pt-6">
                <div className="mb-6 mx-auto w-20 h-20 flex items-center justify-center bg-gray-100 rounded-full">
                  <Heart size={32} className="text-gray-400" />
                </div>
                <h2 className="text-2xl font-bold mb-2">Your wishlist is empty</h2>
                <p className="text-gray-500 mb-6">Looks like you haven't added any products to your wishlist yet.</p>
                <Button asChild>
                  <Link to="/products">Explore Products</Link>
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12 mt-auto">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">ShopSymphony</h3>
              <p className="text-gray-400">Your one-stop shop for all your needs.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><Link to="/" className="text-gray-400 hover:text-white">Home</Link></li>
                <li><Link to="/products" className="text-gray-400 hover:text-white">Products</Link></li>
                <li><Link to="/about" className="text-gray-400 hover:text-white">About Us</Link></li>
                <li><Link to="/contact" className="text-gray-400 hover:text-white">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Customer Service</h4>
              <ul className="space-y-2">
                <li><Link to="/faq" className="text-gray-400 hover:text-white">FAQ</Link></li>
                <li><Link to="/shipping" className="text-gray-400 hover:text-white">Shipping</Link></li>
                <li><Link to="/returns" className="text-gray-400 hover:text-white">Returns</Link></li>
                <li><Link to="/track-order" className="text-gray-400 hover:text-white">Track Order</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact Us</h4>
              <address className="text-gray-400 not-italic">
                <p>Solapur district of Maharashtra, India 413401</p>
                <p className="mt-2">Email: support@shopsymphony.com</p>
                <p>Phone: (123) 456-7890</p>
              </address>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} ShopSymphony. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Wishlist;
