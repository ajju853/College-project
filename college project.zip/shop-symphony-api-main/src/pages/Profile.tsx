import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { ShoppingCart, Search, Heart, User, Package, CreditCard, LogOut, Settings } from "lucide-react";

const Profile = () => {
  // Mock user data
  const userData = {
    name: "John Doe",
    email: "john.doe@example.com",
    joinDate: "January 2023",
    address: "123 Main Street, San Francisco, CA 94103",
    orders: [
      { id: "#ORD-5123", date: "October 15, 2023", status: "Delivered", total: 159.99 },
      { id: "#ORD-4897", date: "September 22, 2023", status: "Delivered", total: 89.95 },
      { id: "#ORD-4562", date: "August 3, 2023", status: "Delivered", total: 212.50 }
    ],
    wishlist: 5
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-gray-800">ShopSymphony</h1>
            </div>
            
            <div className="hidden md:flex items-center space-x-6">
              <Link to="/" className="text-gray-700 hover:text-gray-900 font-medium">Home</Link>
              <Link to="/products" className="text-gray-700 hover:text-gray-900 font-medium">Products</Link>
              <Link to="/categories" className="text-gray-700 hover:text-gray-900 font-medium">Categories</Link>
              <Link to="/deals" className="text-gray-700 hover:text-gray-900 font-medium">Deals</Link>
            </div>
            
            <div className="flex items-center space-x-4">
              <button className="text-gray-700 hover:text-gray-900">
                <Search size={20} />
              </button>
              <Link to="/profile" className="text-blue-600">
                <User size={20} />
              </Link>
              <Link to="/wishlist" className="text-gray-700 hover:text-gray-900">
                <Heart size={20} />
              </Link>
              <Link to="/cart" className="text-gray-700 hover:text-gray-900 relative">
                <ShoppingCart size={20} />
                <span className="absolute -top-2 -right-2 bg-blue-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  0
                </span>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Profile Section */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Sidebar */}
            <div className="md:w-1/4">
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col items-center text-center mb-6">
                    <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mb-4">
                      <User size={40} className="text-gray-500" />
                    </div>
                    <h2 className="text-xl font-bold">{userData.name}</h2>
                    <p className="text-gray-500">{userData.email}</p>
                    <p className="text-sm text-gray-400">Member since {userData.joinDate}</p>
                  </div>
                  
                  <nav className="space-y-2">
                    <Button variant="ghost" className="w-full justify-start">
                      <User size={18} className="mr-2" /> Account Info
                    </Button>
                    <Button variant="ghost" className="w-full justify-start">
                      <Package size={18} className="mr-2" /> My Orders
                    </Button>
                    <Button variant="ghost" className="w-full justify-start">
                      <Heart size={18} className="mr-2" /> Wishlist
                    </Button>
                    <Button variant="ghost" className="w-full justify-start">
                      <CreditCard size={18} className="mr-2" /> Payment Methods
                    </Button>
                    <Button variant="ghost" className="w-full justify-start">
                      <Settings size={18} className="mr-2" /> Settings
                    </Button>
                    <Button variant="ghost" className="w-full justify-start text-red-500 hover:text-red-700 hover:bg-red-50">
                      <LogOut size={18} className="mr-2" /> Sign Out
                    </Button>
                  </nav>
                </CardContent>
              </Card>
            </div>
            
            {/* Main Content */}
            <div className="md:w-3/4">
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle>Account Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="font-medium text-gray-500 mb-2">Full Name</h3>
                      <p>{userData.name}</p>
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-500 mb-2">Email Address</h3>
                      <p>{userData.email}</p>
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-500 mb-2">Shipping Address</h3>
                      <p>{userData.address}</p>
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-500 mb-2">Phone Number</h3>
                      <p>+1 (555) 123-4567</p>
                    </div>
                  </div>
                  <Button className="mt-6">Edit Information</Button>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Recent Orders</CardTitle>
                </CardHeader>
                <CardContent>
                  {userData.orders.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left py-3 px-2">Order ID</th>
                            <th className="text-left py-3 px-2">Date</th>
                            <th className="text-left py-3 px-2">Status</th>
                            <th className="text-left py-3 px-2">Total</th>
                            <th className="text-left py-3 px-2">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {userData.orders.map((order) => (
                            <tr key={order.id} className="border-b">
                              <td className="py-3 px-2">{order.id}</td>
                              <td className="py-3 px-2">{order.date}</td>
                              <td className="py-3 px-2">
                                <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">
                                  {order.status}
                                </span>
                              </td>
                              <td className="py-3 px-2">${order.total.toFixed(2)}</td>
                              <td className="py-3 px-2">
                                <Button variant="outline" size="sm">View Order</Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <p className="text-gray-500">You haven't placed any orders yet.</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">ShopSymphony</h3>
              <p className="text-gray-400">Your one-stop shop for all your needs.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><Link to="/" className="text-gray-400 hover:text-white">Home</Link></li>
                <li><Link to="/products" className="text-gray-400 hover:text-white">Products</Link></li>
                <li><Link to="/about" className="text-gray-400 hover:text-white">About Us</Link></li>
                <li><Link to="/contact" className="text-gray-400 hover:text-white">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Customer Service</h4>
              <ul className="space-y-2">
                <li><Link to="/faq" className="text-gray-400 hover:text-white">FAQ</Link></li>
                <li><Link to="/shipping" className="text-gray-400 hover:text-white">Shipping</Link></li>
                <li><Link to="/returns" className="text-gray-400 hover:text-white">Returns</Link></li>
                <li><Link to="/track-order" className="text-gray-400 hover:text-white">Track Order</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact Us</h4>
              <address className="text-gray-400 not-italic">
                <p>Solapur district of Maharashtra, India 413401</p>
                <p className="mt-2">Email: support@shopsymphony.com</p>
                <p>Phone: (123) 456-7890</p>
              </address>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} ShopSymphony. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Profile;
