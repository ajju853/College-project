import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { ShoppingCart, Search, Heart, User } from "lucide-react";

const Categories = () => {
  // Categories with their subcategories
  const categories = [
    {
      name: "Electronics",
      image: "https://images.unsplash.com/photo-1498049794561-7780e7231661?w=500&auto=format&fit=crop&q=80",
      subcategories: ["Smartphones", "Laptops", "Audio", "Cameras", "Accessories"]
    },
    {
      name: "Clothing",
      image: "https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?w=500&auto=format&fit=crop&q=80",
      subcategories: ["Men's", "Women's", "Kids", "Sportswear", "Accessories"]
    },
    {
      name: "Home & Kitchen",
      image: "https://images.unsplash.com/photo-1556912172-45b7abe8b7e1?w=500&auto=format&fit=crop&q=80",
      subcategories: ["Furniture", "Cookware", "Appliances", "Decor", "Storage"]
    },
    {
      name: "Beauty",
      image: "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=500&auto=format&fit=crop&q=80",
      subcategories: ["Skincare", "Makeup", "Haircare", "Fragrances", "Tools"]
    },
    {
      name: "Sports & Outdoors",
      image: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=500&auto=format&fit=crop&q=80",
      subcategories: ["Fitness", "Camping", "Cycling", "Team Sports", "Water Sports"]
    },
    {
      name: "Books & Stationery",
      image: "https://images.unsplash.com/photo-1507842217343-583bb7270b66?w=500&auto=format&fit=crop&q=80",
      subcategories: ["Fiction", "Non-Fiction", "Academic", "Office Supplies", "Arts & Crafts"]
    },
    {
      name: "Toys & Games",
      image: "https://images.unsplash.com/photo-1558060370-d365059b6540?w=500&auto=format&fit=crop&q=80",
      subcategories: ["Action Figures", "Board Games", "Puzzles", "Educational", "Outdoor Toys"]
    },
    {
      name: "Health & Wellness",
      image: "https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=500&auto=format&fit=crop&q=80",
      subcategories: ["Vitamins", "Fitness Equipment", "Personal Care", "Health Monitors", "Wellness Books"]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-gray-800">ShopSymphony</h1>
            </div>
            
            <div className="hidden md:flex items-center space-x-6">
              <Link to="/" className="text-gray-700 hover:text-gray-900 font-medium">Home</Link>
              <Link to="/products" className="text-gray-700 hover:text-gray-900 font-medium">Products</Link>
              <Link to="/categories" className="text-blue-600 font-medium">Categories</Link>
              <Link to="/deals" className="text-gray-700 hover:text-gray-900 font-medium">Deals</Link>
            </div>
            
            <div className="flex items-center space-x-4">
              <button className="text-gray-700 hover:text-gray-900">
                <Search size={20} />
              </button>
              <Link to="/profile" className="text-gray-700 hover:text-gray-900">
                <User size={20} />
              </Link>
              <Link to="/wishlist" className="text-gray-700 hover:text-gray-900">
                <Heart size={20} />
              </Link>
              <Link to="/cart" className="text-gray-700 hover:text-gray-900 relative">
                <ShoppingCart size={20} />
                <span className="absolute -top-2 -right-2 bg-blue-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  0
                </span>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Categories Section */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold mb-8">Shop by Category</h1>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((category) => (
              <Card key={category.name} className="hover:shadow-lg transition-shadow overflow-hidden h-full">
                <CardContent className="p-0">
                  <img 
                    src={category.image} 
                    alt={category.name}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-6">
                    <h3 className="text-xl font-semibold mb-4">{category.name}</h3>
                    <ul className="space-y-2">
                      {category.subcategories.map((subcategory) => (
                        <li key={subcategory}>
                          <Link to={`/products?category=${subcategory}`} className="text-blue-600 hover:text-blue-800">
                            {subcategory}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">ShopSymphony</h3>
              <p className="text-gray-400">Your one-stop shop for all your needs.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><Link to="/" className="text-gray-400 hover:text-white">Home</Link></li>
                <li><Link to="/products" className="text-gray-400 hover:text-white">Products</Link></li>
                <li><Link to="/about" className="text-gray-400 hover:text-white">About Us</Link></li>
                <li><Link to="/contact" className="text-gray-400 hover:text-white">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Customer Service</h4>
              <ul className="space-y-2">
                <li><Link to="/faq" className="text-gray-400 hover:text-white">FAQ</Link></li>
                <li><Link to="/shipping" className="text-gray-400 hover:text-white">Shipping</Link></li>
                <li><Link to="/returns" className="text-gray-400 hover:text-white">Returns</Link></li>
                <li><Link to="/track-order" className="text-gray-400 hover:text-white">Track Order</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact Us</h4>
              <address className="text-gray-400 not-italic">
                <p>Solapur district of Maharashtra, India 413401</p>
                <p className="mt-2">Email: support@shopsymphony.com</p>
                <p>Phone: (123) 456-7890</p>
              </address>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} ShopSymphony. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Categories;
