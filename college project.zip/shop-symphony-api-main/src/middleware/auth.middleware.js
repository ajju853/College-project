
const jwt = require('jsonwebtoken');
const User = require('../models/user.model');
const { ApiError } = require('../utils/api-error');

/**
 * Middleware to verify JWT token and attach user to request object
 */
const authenticate = async (req, res, next) => {
  try {
    // Get token from authorization header
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return next(new ApiError('Authentication required', 401));
    }
    
    const token = authHeader.split(' ')[1];
    
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Find user by id
    const user = await User.findById(decoded.id).select('-password');
    
    if (!user) {
      return next(new ApiError('User not found', 404));
    }
    
    if (!user.isActive) {
      return next(new ApiError('User account has been deactivated', 403));
    }
    
    // Attach user to request object
    req.user = user;
    next();
  } catch (error) {
    if (error.name === 'JsonWebTokenError') {
      return next(new ApiError('Invalid token', 401));
    }
    if (error.name === 'TokenExpiredError') {
      return next(new ApiError('Token expired', 401));
    }
    next(error);
  }
};

/**
 * Middleware to verify if user is admin
 */
const authorizeAdmin = (req, res, next) => {
  if (req.user && req.user.role === 'admin') {
    return next();
  }
  return next(new ApiError('Access denied: Admin privileges required', 403));
};

module.exports = { authenticate, authorizeAdmin };
